﻿using MudCore.Entities;
using MudCore.World;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using MudNetworking;


namespace MudServer
{
    public class CommandHandler
    {
        private World _world;

        public CommandHandler(World world)
        {
            _world = world;
        }

        /// <summary>
        /// Process a player command and return a response string.
        /// AI-SAFE: Only interprets commands, does not modify core World structure.
        /// </summary>
        public string ProcessCommand(Player player, string command)
        {
            command = command.Trim().ToLower();

            switch (command)
            {
                case "look":
                    var npcs = _world.CurrentRoom.Npcs
                        .Select(n => $"{n.Name} is here. {n.IdleAction}")
                        .ToList();
                    var players = _world.Players
                        .Where(p => p != player)
                        .Select(p => $"{p.Name} is here.")
                        .ToList();

                    return MessageHandler.Serialize(
                        MessageHandler.Room(_world.CurrentRoom.Description, npcs, players)
                    );

                default:
                    return MessageHandler.Serialize(
                        MessageHandler.System($"Unknown command: {command}")
                    );
            }
        }


        // AI-SAFE: minimal implementations, can expand safely
        private string Look(Player player)
        {
            var room = player.CurrentRoom;

            if (room == null)
                return "You are lost in the void.";

            var sb = new StringBuilder();
            sb.AppendLine(room.Description);
            sb.AppendLine();

            // NPC descriptions
            foreach (var npc in room.Npcs)
            {
                sb.AppendLine($"A {npc.Name} is here. {npc.LastAction}");
            }

            // Events (excluding the player's own actions)
            sb.AppendLine();
            sb.AppendLine("Recent activity:");
            foreach (var evt in room.GetEvents())
                sb.AppendLine($"- {evt}");

            return sb.ToString();
        }

        private string Move(Player player)
        {
            return "You take a step forward (movement not yet implemented).";
        }

        private string Attack(Player player)
        {
            if (_world.Npcs.Count == 0)
                return "There is nothing to attack.";

            var target = _world.Npcs[0]; // simplistic: attack first NPC
            target.Health -= 5;

            string result = $"You attack {target.Name} for 5 damage. Remaining HP: {target.Health}";

            if (target.Health <= 0)
            {
                _world.Npcs.Remove(target);
                result += $"\n{target.Name} has been defeated!";
            }

            return result;
        }
    }
}
